using UnityEngine;

public class Slot : MonoBehaviour
{
    public GameObject currentItem;
}
